// features/menu/models/coffee.ts
export interface Coffee {
  id: number;
  name: string;
  price: number;
  description: string;
  image: string;
}
